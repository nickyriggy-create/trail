package dev.trailmark;

public record Waypoint(String name, String dimension, int x, int y, int z) {
    public String coords() { return x + ", " + y + ", " + z; }
}
