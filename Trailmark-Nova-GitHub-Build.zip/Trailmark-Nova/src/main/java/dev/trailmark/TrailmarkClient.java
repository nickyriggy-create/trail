package dev.trailmark;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.lwjgl.glfw.GLFW;

public final class TrailmarkClient implements ClientModInitializer {
    private static KeyMapping openMenu;

    @Override
    public void onInitializeClient() {
        var category = KeyMapping.Category.register(
                ResourceLocation.fromNamespaceAndPath("trailmark", "controls"));
        openMenu = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.trailmark.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.consumeClick()) {
                if (client.player != null) client.setScreen(new NovaScreen());
            }
        });

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("trailmark", "scout_hud"),
                TrailmarkClient::renderHud
        );
    }

    private static void renderHud(GuiGraphicsExtractor g, net.minecraft.client.DeltaTracker tick) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;

        var p = mc.player.blockPosition();
        int x = 12, y = 12;
        g.fill(x, y, x + 164, y + 54, 0xD9101724);
        g.fill(x, y, x + 164, y + 2, 0xFF61E6C2);
        g.drawString(mc.font, Component.literal("TRAILMARK  /  NOVA"), x + 10, y + 8, 0xFF61E6C2);
        g.drawString(mc.font, Component.literal("XYZ  " + p.getX() + "  " + p.getY() + "  " + p.getZ()),
                x + 10, y + 23, 0xFFF0F4FA);
        g.drawString(mc.font, Component.literal("DIM  " + mc.level.dimension().location()),
                x + 10, y + 38, 0xFF9EACC0);
    }
}
