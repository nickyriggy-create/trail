package dev.trailmark;

import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class WaypointStore {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("trailmark-nova.tsv");
    private WaypointStore() {}

    public static List<Waypoint> load() {
        var out = new ArrayList<Waypoint>();
        if (!Files.exists(FILE)) return out;
        try {
            for (String line : Files.readAllLines(FILE, StandardCharsets.UTF_8)) {
                String[] a = line.split("\\t", -1);
                if (a.length != 5) continue;
                try { out.add(new Waypoint(a[0], a[1], Integer.parseInt(a[2]),
                        Integer.parseInt(a[3]), Integer.parseInt(a[4]))); }
                catch (NumberFormatException ignored) {}
            }
        } catch (IOException ignored) {}
        return out;
    }

    public static void save(List<Waypoint> points) {
        var lines = points.stream().map(w -> clean(w.name()) + "\\t" + clean(w.dimension()) +
                "\\t" + w.x() + "\\t" + w.y() + "\\t" + w.z()).toList();
        try {
            Files.createDirectories(FILE.getParent());
            Files.write(FILE, lines, StandardCharsets.UTF_8);
        } catch (IOException e) { throw new IllegalStateException("Could not save waypoint file", e); }
    }

    private static String clean(String s) { return s.replace("\\t", " ").replace("\\n", " "); }
}
