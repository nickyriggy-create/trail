package dev.trailmark;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public final class NovaScreen extends Screen {
    private final List<Waypoint> points = new ArrayList<>();
    private int scroll = 0;

    public NovaScreen() {
        super(Component.literal("Trailmark Nova"));
        points.addAll(WaypointStore.load());
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int left = cx - 176;
        int top = height / 2 - 112;

        addRenderableWidget(Button.builder(Component.literal("+  SAVE LOCATION"), b -> savePoint())
                .bounds(left + 18, top + 164, 164, 22).build());
        addRenderableWidget(Button.builder(Component.literal("DELETE NEWEST"), b -> deleteNewest())
                .bounds(left + 18, top + 190, 164, 20).build());
        addRenderableWidget(Button.builder(Component.literal("CLOSE"), b -> onClose())
                .bounds(left + 18, top + 214, 164, 20).build());
        addRenderableWidget(Button.builder(Component.literal("↑"), b -> scroll = Math.max(0, scroll - 1))
                .bounds(left + 342, top + 54, 18, 18).build());
        addRenderableWidget(Button.builder(Component.literal("↓"), b -> scroll = Math.min(Math.max(0, points.size() - 5), scroll + 1))
                .bounds(left + 342, top + 76, 18, 18).build());
    }

    private void savePoint() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || points.size() >= 30) return;
        var p = mc.player.blockPosition();
        points.add(new Waypoint("Scout " + (points.size() + 1),
                mc.level.dimension().location().toString(), p.getX(), p.getY(), p.getZ()));
        WaypointStore.save(points);
    }

    private void deleteNewest() {
        if (points.isEmpty()) return;
        points.remove(points.size() - 1);
        scroll = Math.min(scroll, Math.max(0, points.size() - 5));
        WaypointStore.save(points);
    }

    @Override
    public void render(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0xB8000000);

        int left = width / 2 - 176;
        int top = height / 2 - 112;
        int right = left + 370;
        int bottom = top + 246;

        g.fill(left, top, right, bottom, 0xF00C1220);
        g.fill(left, top, right, top + 2, 0xFF61E6C2);
        g.fill(left, top, left + 190, bottom, 0xFF111C2D);
        g.fill(left + 190, top + 34, left + 191, bottom - 12, 0xFF26364B);

        g.drawString(font, Component.literal("TRAILMARK"), left + 18, top + 15, 0xFFFFFFFF);
        g.drawString(font, Component.literal("N O V A   /   SCOUT CONSOLE"), left + 18, top + 29, 0xFF61E6C2);
        g.drawString(font, Component.literal("OVERVIEW"), left + 18, top + 52, 0xFF8FA3BA);
        g.drawString(font, Component.literal("LOCAL WAYPOINTS"), left + 18, top + 70, 0xFFFFFFFF);
        g.drawString(font, Component.literal("30 MARKER CAPACITY"), left + 18, top + 84, 0xFF8292A8);

        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.level != null) {
            var p = mc.player.blockPosition();
            g.drawString(font, Component.literal("LIVE POSITION"), left + 210, top + 17, 0xFF61E6C2);
            g.drawString(font, Component.literal("X   " + p.getX()), left + 210, top + 37, 0xFFEAF0F7);
            g.drawString(font, Component.literal("Y   " + p.getY()), left + 210, top + 51, 0xFFEAF0F7);
            g.drawString(font, Component.literal("Z   " + p.getZ()), left + 210, top + 65, 0xFFEAF0F7);
            g.drawString(font, Component.literal(mc.level.dimension().location().toString()),
                    left + 210, top + 81, 0xFF8FA3BA);
        }

        g.drawString(font, Component.literal("SAVED LOCATIONS  /  " + points.size() + " OF 30"),
                left + 210, top + 108, 0xFFFFFFFF);

        int count = Math.min(5, Math.max(0, points.size() - scroll));
        if (count == 0) {
            g.drawString(font, Component.literal("No markers saved yet."), left + 210, top + 132, 0xFF8292A8);
            g.drawString(font, Component.literal("Use SAVE LOCATION to add one."), left + 210, top + 146, 0xFF8292A8);
        }
        for (int i = 0; i < count; i++) {
            Waypoint w = points.get(scroll + i);
            int rowY = top + 126 + i * 19;
            g.fill(left + 208, rowY - 3, right - 12, rowY + 13, 0xFF172438);
            g.fill(left + 208, rowY - 3, left + 210, rowY + 13, 0xFF61E6C2);
            g.drawString(font, Component.literal(w.name() + "   " + w.coords()),
                    left + 216, rowY, 0xFFEAF0F7);
        }

        g.drawString(font, Component.literal("K  /  TOGGLE CONSOLE"), left + 210, bottom - 18, 0xFF70839B);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override public void onClose() { Minecraft.getInstance().setScreen(null); }
    @Override public boolean isPauseScreen() { return false; }
}
