# Trailmark Nova — Fabric client mod

A client-side exploration notebook for Minecraft Java 26.3. Press **K** to open the Nova scout console, view your own live coordinates/dimension, and save or delete manually recorded waypoints.

This mod does not reveal hidden/unloaded blocks, render hidden entities or blocks through walls, scan bases, inspect hidden server data, manipulate sound events, or evade anti-cheat.

## Build and Modrinth pack
The GitHub Actions workflow in `.github/workflows/release.yml` builds with Java 25 and Gradle 9.6, then packages a `.mrpack` containing the compiled mod and a compatible Fabric API dependency. Push this folder to a GitHub repository and run **Actions → Build Trailmark Nova → Run workflow**. Download the `Trailmark-Nova-Modrinth-Pack` artifact and import the `.mrpack` into the Modrinth App.

Target: Minecraft 26.3, Fabric Loader 0.20.1, Fabric API 26.3, Java 25.
