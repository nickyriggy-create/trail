import json, pathlib, urllib.request, zipfile, shutil
ROOT = pathlib.Path(__file__).resolve().parents[1]
DIST = ROOT / 'dist'
DIST.mkdir(exist_ok=True)
mod_jars = [p for p in (ROOT/'build'/'libs').glob('*.jar') if not p.name.endswith('-sources.jar')]
if not mod_jars:
    raise SystemExit('No compiled Trailmark JAR found in build/libs')
# Find a Fabric API release explicitly compatible with Minecraft 26.3.
url = 'https://api.modrinth.com/v2/project/P7dR8mSH/version?loaders=%5B%22fabric%22%5D&game_versions=%5B%2226.3%22%5D'
req = urllib.request.Request(url, headers={'User-Agent':'TrailmarkNova/2.0.0 (modpack builder)'})
with urllib.request.urlopen(req, timeout=30) as response:
    versions = json.load(response)
if not versions:
    raise SystemExit('Modrinth API returned no Fabric API version for Minecraft 26.3')
api_version = versions[0]
api_file = next((f for f in api_version['files'] if f.get('primary')), api_version['files'][0])
index = {
  'formatVersion': 1,
  'game': 'minecraft',
  'versionId': '2.0.0',
  'name': 'Trailmark Nova — Fabric 26.3',
  'summary': 'Trailmark Nova scouting notebook and waypoint HUD.',
  'files': [
    {'path': 'mods/' + mod_jars[0].name, 'hashes': {}, 'env': {'client':'required','server':'unsupported'}}
  ],
  'dependencies': {
    'minecraft': '26.3',
    'fabric-loader': '0.20.1',
    'P7dR8mSH': api_version['id']
  }
}
out = DIST/'Trailmark-Nova-Fabric-26.3.mrpack'
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    z.writestr('modrinth.index.json', json.dumps(index, indent=2))
    z.write(mod_jars[0], 'overrides/mods/' + mod_jars[0].name)
print(f'Created {out}')
